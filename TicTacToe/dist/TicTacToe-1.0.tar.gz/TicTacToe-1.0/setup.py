from setuptools import setup

setup(
    name='TicTacToe',
    version='1.0',
    description='Simple tictactoe game',
    author='Alicja Polanowska',
    py_modules=['tictactoe'],
)
